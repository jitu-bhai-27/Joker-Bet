import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { DepositReservation } from '../../types/index';
import {
  Coins,
  ArrowDownToLine,
  ArrowUpFromLine,
  QrCode,
  Copy,
  Clock,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  Lock,
} from 'lucide-react';

export const WalletScreen: React.FC = () => {
  const { user, config, activeRoom, walletTab, setWalletTab, refreshUserData } = useApp();

  // Deposit states
  const [depositAmount, setDepositAmount] = useState<number>(100);
  const [reservation, setReservation] = useState<DepositReservation | null>(null);
  const [utrInput, setUtrInput] = useState('');
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [loading, setLoading] = useState(false);
  const [depositMsg, setDepositMsg] = useState<{ type: 'success' | 'error' | 'warning'; text: string } | null>(null);
  const [remainingTimeSec, setRemainingTimeSec] = useState<number>(600);

  // Edge case test toggles
  const [simulateDelay, setSimulateDelay] = useState(false);
  const [simulateMismatch, setSimulateMismatch] = useState(false);
  const [mismatchModalOpen, setMismatchModalOpen] = useState(false);
  const [correctedAmountInput, setCorrectedAmountInput] = useState('');

  // Withdrawal states
  const [withdrawCoins, setWithdrawCoins] = useState<number>(500);
  const [withdrawUpi, setWithdrawUpi] = useState('');
  const [withdrawBank, setWithdrawBank] = useState('');
  const [withdrawHolder, setWithdrawHolder] = useState('');
  const [withdrawLoading, setWithdrawLoading] = useState(false);
  const [withdrawMsg, setWithdrawMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // 10-Minute Reservation timer
  useEffect(() => {
    if (!reservation || !reservation.expiresAt) return;

    const tick = () => {
      const diff = Math.max(0, Math.floor((new Date(reservation.expiresAt).getTime() - Date.now()) / 1000));
      setRemainingTimeSec(diff);
      if (diff === 0) {
        setReservation(null);
        setDepositMsg({ type: 'error', text: '10-minute reservation expired. Please generate a fresh deposit session.' });
      }
    };

    tick();
    const timer = setInterval(tick, 1000);
    return () => clearInterval(timer);
  }, [reservation]);

  // Handle Reserve QR
  const handleReserveQr = async () => {
    if (!depositAmount || depositAmount < (config?.minDeposit || 10)) {
      setDepositMsg({
        type: 'error',
        text: `Minimum deposit amount is ${config?.minDeposit || 10} Coins`,
      });
      return;
    }

    setDepositMsg(null);
    setLoading(true);
    try {
      const res = await api.reserveQr(depositAmount);
      if (res.success && res.reservation) {
        setReservation(res.reservation);
        setUtrInput('');
      }
    } catch (err: any) {
      setDepositMsg({ type: 'error', text: err.message || 'Gateway limit reservation failed' });
    } finally {
      setLoading(false);
    }
  };

  // Submit UTR
  const handleSubmitUtr = async () => {
    if (!reservation) return;
    if (!utrInput || utrInput.length !== 12 || !/^\d{12}$/.test(utrInput)) {
      setDepositMsg({ type: 'error', text: 'Please enter a valid 12-digit numeric Bank UTR Number.' });
      return;
    }

    setDepositMsg(null);
    setLoading(true);
    try {
      const res = await api.submitUtr(reservation.id, utrInput, simulateDelay, simulateMismatch);
      if (res.success) {
        setDepositMsg({ type: 'success', text: res.message });
        setReservation(null);
        await refreshUserData();
      } else if (res.code === 'BANK_SYNC_DELAY') {
        // Edge Case 5: Bank Latency
        setDepositMsg({ type: 'warning', text: res.message });
      } else if (res.code === 'AMOUNT_MISMATCH') {
        // Edge Case 6: Amount Mismatch
        setMismatchModalOpen(true);
      }
    } catch (err: any) {
      setDepositMsg({ type: 'error', text: err.message || 'Verification failed' });
    } finally {
      setLoading(false);
    }
  };

  // Single-Attempt Amount Correction (Anti-Brute-Force Safeguard)
  const handleAmountCorrection = async () => {
    if (!reservation) return;
    setLoading(true);
    try {
      const res = await api.correctDepositAmount(reservation.id, Number(correctedAmountInput));
      if (res.success) {
        setMismatchModalOpen(false);
        setReservation(null);
        setDepositMsg({ type: 'success', text: res.message });
        await refreshUserData();
      }
    } catch (err: any) {
      setMismatchModalOpen(false);
      setDepositMsg({ type: 'error', text: err.message || 'Amount correction failed. UTR locked.' });
    } finally {
      setLoading(false);
    }
  };

  // Handle Withdrawal Request
  const handleWithdrawal = async () => {
    if (activeRoom) {
      setWithdrawMsg({
        type: 'error',
        text: 'Withdrawals are strictly locked while registered in an active game or waiting room.',
      });
      return;
    }

    const minWdr = config?.minWithdrawal || 100;
    if (!withdrawCoins || withdrawCoins < minWdr) {
      setWithdrawMsg({ type: 'error', text: `Minimum withdrawal is ${minWdr} Coins` });
      return;
    }

    if ((user?.coins || 0) < withdrawCoins) {
      setWithdrawMsg({ type: 'error', text: 'Insufficient balance' });
      return;
    }

    if (!withdrawUpi && !withdrawBank) {
      setWithdrawMsg({ type: 'error', text: 'Please provide either UPI ID or Bank Account Details' });
      return;
    }

    setWithdrawMsg(null);
    setWithdrawLoading(true);
    try {
      const res = await api.withdraw({
        coins: withdrawCoins,
        upiId: withdrawUpi,
        bankName: withdrawBank,
        accountHolderName: withdrawHolder,
      });

      if (res.success) {
        setWithdrawMsg({ type: 'success', text: res.message });
        await refreshUserData();
      }
    } catch (err: any) {
      setWithdrawMsg({ type: 'error', text: err.message || 'Withdrawal failed' });
    } finally {
      setWithdrawLoading(false);
    }
  };

  const copyUpiId = () => {
    if (reservation?.upiId) {
      navigator.clipboard.writeText(reservation.upiId);
      setCopiedUpi(true);
      setTimeout(() => setCopiedUpi(false), 2000);
    }
  };

  // Fee calculation
  const feePercent = config?.commissionFeePercent || 5;
  const calculatedFee = Math.round(withdrawCoins * (feePercent / 100));
  const netPayout = Math.max(0, withdrawCoins - calculatedFee);

  const formatSec = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="w-full flex-1 flex flex-col justify-between p-4 bg-[#07090e] text-slate-100 select-none pb-16">
      <div>
        {/* Wallet Balance Hero Card */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-950/40 via-[#101522] to-[#0c101a] border border-amber-500/40 shadow-xl mb-4">
          <div className="flex items-center justify-between">
            <span className="text-xs uppercase tracking-wider text-slate-400 font-semibold">
              Available Playable Balance
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-mono">
              1 Coin = ₹1.00 INR
            </span>
          </div>

          <div className="flex items-baseline gap-2 mt-2">
            <Coins className="w-6 h-6 text-amber-400 self-center" />
            <span className="text-3xl font-black text-amber-200 font-mono">
              {user?.coins?.toLocaleString() || 0}
            </span>
            <span className="text-xs text-slate-400 font-semibold uppercase">Coins (₹{user?.coins?.toLocaleString() || 0})</span>
          </div>

          <p className="text-[10px] text-slate-400 mt-1">
            Universal ledger: Game winnings and deposits merge directly with zero playthrough lockups.
          </p>
        </div>

        {/* Tab Switcher: [DEPOSIT] | [WITHDRAWAL] */}
        <div className="grid grid-cols-2 gap-2 bg-[#0c101c] p-1.5 rounded-2xl border border-slate-800 mb-4">
          <button
            onClick={() => setWalletTab('DEPOSIT')}
            className={`py-2.5 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition-all ${
              walletTab === 'DEPOSIT'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-black shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ArrowDownToLine className="w-4 h-4" />
            <span>Deposit (UPI QR)</span>
          </button>

          <button
            onClick={() => setWalletTab('WITHDRAWAL')}
            className={`py-2.5 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition-all ${
              walletTab === 'WITHDRAWAL'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-black shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ArrowUpFromLine className="w-4 h-4" />
            <span>Withdrawal (Bank)</span>
          </button>
        </div>

        {/* =================================================================== */}
        {/* DEPOSIT VIEW */}
        {/* =================================================================== */}
        {walletTab === 'DEPOSIT' && (
          <div className="space-y-4">
            {/* Status Feedback */}
            {depositMsg && (
              <div
                className={`p-3 rounded-xl border flex items-center gap-2 text-xs leading-relaxed ${
                  depositMsg.type === 'success'
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                    : depositMsg.type === 'warning'
                    ? 'bg-yellow-500/10 border-yellow-500/30 text-yellow-300'
                    : 'bg-red-500/10 border-red-500/30 text-red-300'
                }`}
              >
                {depositMsg.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                ) : (
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                )}
                <span>{depositMsg.text}</span>
              </div>
            )}

            {!reservation ? (
              /* Amount Selection Step */
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1.5 uppercase tracking-wider">
                    Deposit Coins (1 Coin = ₹1 INR)
                  </label>
                  <input
                    type="number"
                    min={config?.minDeposit || 10}
                    value={depositAmount}
                    onChange={(e) => setDepositAmount(Number(e.target.value))}
                    className="w-full bg-[#0d121c] border border-slate-700 rounded-xl px-4 py-3 text-lg font-mono font-bold text-amber-300 focus:outline-none focus:border-amber-500"
                  />
                </div>

                {/* Quick Chips */}
                <div className="grid grid-cols-3 gap-2">
                  {[50, 100, 500, 1000, 2000, 5000].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setDepositAmount(amt)}
                      className={`py-2 rounded-xl text-xs font-bold border font-mono transition-all ${
                        depositAmount === amt
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                          : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
                      }`}
                    >
                      +{amt} Coins
                    </button>
                  ))}
                </div>

                {/* Generate Active Reservation */}
                <button
                  onClick={handleReserveQr}
                  disabled={loading || depositAmount < (config?.minDeposit || 10)}
                  className="w-full py-3.5 bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-400 text-black font-extrabold text-sm rounded-xl shadow-lg transition-all flex items-center justify-center gap-2"
                >
                  <QrCode className="w-4 h-4" />
                  <span>{loading ? 'Reserving Gateway...' : 'Generate Dynamic QR & Pay'}</span>
                </button>
              </div>
            ) : (
              /* Active Reserved QR Session Step */
              <div className="p-4 rounded-2xl bg-[#0c101c] border border-amber-500/30 space-y-4">
                {/* 10-Minute Reservation Timer Banner */}
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs">
                  <div className="flex items-center gap-1.5 text-amber-300 font-bold">
                    <Clock className="w-4 h-4 animate-spin" style={{ animationDuration: '4s' }} />
                    <span>Session Expires In:</span>
                  </div>
                  <span className="font-mono font-black text-amber-200 text-sm">
                    {formatSec(remainingTimeSec)}
                  </span>
                </div>

                {/* QR Code Graphic Container */}
                <div className="flex flex-col items-center justify-center p-3 bg-white rounded-2xl max-w-[220px] mx-auto shadow-xl">
                  <img
                    src={reservation.qrImageUrl}
                    alt="Scan UPI QR"
                    className="w-48 h-48 object-contain"
                  />
                  <span className="text-[10px] font-bold text-slate-800 mt-1 uppercase tracking-wider font-mono">
                    Scan with Any UPI App
                  </span>
                </div>

                {/* Payment Breakdown */}
                <div className="text-center space-y-1">
                  <div className="text-xs text-slate-400">Exact Payable Amount:</div>
                  <div className="text-2xl font-black text-amber-300 font-mono">
                    ₹{reservation.amount}.00 INR
                  </div>
                </div>

                {/* Copy UPI VPA */}
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#07090e] border border-slate-700 text-xs">
                  <span className="font-mono text-slate-300 truncate pr-2">{reservation.upiId}</span>
                  <button
                    onClick={copyUpiId}
                    className="flex items-center gap-1 text-[11px] font-bold text-amber-400 hover:text-amber-300 shrink-0"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>{copiedUpi ? 'Copied!' : 'Copy UPI'}</span>
                  </button>
                </div>

                {/* UPI Intent Shortcuts */}
                <div className="grid grid-cols-3 gap-2">
                  <a
                    href={`upi://pay?pa=${reservation.upiId}&pn=JokerBet&am=${reservation.amount}&cu=INR`}
                    className="py-2 rounded-xl bg-[#1a2333] hover:bg-[#202b3e] text-center text-[11px] font-bold text-slate-200 border border-slate-700"
                  >
                    Google Pay
                  </a>
                  <a
                    href={`upi://pay?pa=${reservation.upiId}&pn=JokerBet&am=${reservation.amount}&cu=INR`}
                    className="py-2 rounded-xl bg-[#1a2333] hover:bg-[#202b3e] text-center text-[11px] font-bold text-slate-200 border border-slate-700"
                  >
                    PhonePe
                  </a>
                  <a
                    href={`upi://pay?pa=${reservation.upiId}&pn=JokerBet&am=${reservation.amount}&cu=INR`}
                    className="py-2 rounded-xl bg-[#1a2333] hover:bg-[#202b3e] text-center text-[11px] font-bold text-slate-200 border border-slate-700"
                  >
                    Paytm
                  </a>
                </div>

                {/* 12-Digit UTR Submission Form */}
                <div className="pt-2 border-t border-slate-800 space-y-2.5">
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                    Enter 12-Digit Bank UTR / Ref Number
                  </label>
                  <input
                    type="text"
                    maxLength={12}
                    value={utrInput}
                    onChange={(e) => setUtrInput(e.target.value.replace(/\D/g, ''))}
                    placeholder="e.g. 408512349876"
                    className="w-full bg-[#07090e] border border-slate-700 rounded-xl px-4 py-3 text-sm font-mono tracking-wider text-amber-200 placeholder-slate-600 focus:outline-none focus:border-amber-500"
                  />

                  {/* Edge Case Simulation Toggles (For testing specifications) */}
                  <div className="p-2 rounded-lg bg-slate-900/60 border border-slate-800 text-[10px] space-y-1">
                    <div className="font-semibold text-slate-400">Developer Testing Sandbox:</div>
                    <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={simulateDelay}
                        onChange={(e) => setSimulateDelay(e.target.checked)}
                      />
                      <span>Test Edge Case 5 (Bank Latency &quot;Verify Again&quot;)</span>
                    </label>
                    <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={simulateMismatch}
                        onChange={(e) => setSimulateMismatch(e.target.checked)}
                      />
                      <span>Test Edge Case 6 (Amount Mismatch Correction Flow)</span>
                    </label>
                  </div>

                  <button
                    onClick={handleSubmitUtr}
                    disabled={loading || utrInput.length !== 12}
                    className={`w-full py-3.5 rounded-xl font-black text-xs uppercase tracking-wider shadow-lg transition-all ${
                      loading || utrInput.length !== 12
                        ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                        : 'bg-emerald-500 hover:bg-emerald-400 text-black shadow-[0_0_20px_rgba(16,185,129,0.3)]'
                    }`}
                  >
                    {loading ? 'Verifying with Bank...' : 'Submit 12-Digit UTR for Verification'}
                  </button>

                  <button
                    onClick={() => setReservation(null)}
                    className="w-full py-1 text-center text-[11px] text-slate-500 hover:text-slate-400"
                  >
                    Cancel Session & Generate New
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* =================================================================== */}
        {/* WITHDRAWAL VIEW */}
        {/* =================================================================== */}
        {walletTab === 'WITHDRAWAL' && (
          <div className="space-y-4">
            {/* Active Room Lock Notice */}
            {activeRoom && (
              <div className="p-3 bg-red-500/10 border border-red-500/40 rounded-xl flex items-center gap-2.5 text-xs text-red-300">
                <Lock className="w-5 h-5 text-red-400 shrink-0" />
                <div>
                  <div className="font-bold">Withdrawal Locked</div>
                  <div>You are currently registered in an active game or waiting room. Please exit or conclude your table first.</div>
                </div>
              </div>
            )}

            {/* Withdrawal Status Feedback */}
            {withdrawMsg && (
              <div
                className={`p-3 rounded-xl border flex items-center gap-2 text-xs ${
                  withdrawMsg.type === 'success'
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                    : 'bg-red-500/10 border-red-500/30 text-red-300'
                }`}
              >
                {withdrawMsg.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                ) : (
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                )}
                <span>{withdrawMsg.text}</span>
              </div>
            )}

            {/* Withdrawal Form */}
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1 uppercase tracking-wider">
                  Withdrawal Coins (Min: {config?.minWithdrawal || 100})
                </label>
                <input
                  type="number"
                  min={config?.minWithdrawal || 100}
                  value={withdrawCoins}
                  onChange={(e) => setWithdrawCoins(Number(e.target.value))}
                  disabled={Boolean(activeRoom)}
                  className="w-full bg-[#0d121c] border border-slate-700 rounded-xl px-4 py-3 text-lg font-mono font-bold text-amber-300 focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Dynamic Fee Breakdown Card */}
              <div className="p-3 rounded-xl bg-[#0b0e17] border border-slate-800 space-y-1.5 text-xs">
                <div className="flex justify-between text-slate-400">
                  <span>Requested Coins:</span>
                  <span className="font-mono text-slate-200">{withdrawCoins} Coins</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Platform Commission ({feePercent}%):</span>
                  <span className="font-mono text-amber-400">-{calculatedFee} Coins</span>
                </div>
                <div className="flex justify-between font-bold text-emerald-400 border-t border-slate-800 pt-1.5 text-sm">
                  <span>Net Bank Payout (INR):</span>
                  <span className="font-mono font-black text-base">₹{netPayout.toFixed(2)}</span>
                </div>
              </div>

              {/* UPI ID */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1 uppercase tracking-wider">
                  Target UPI ID (Instant)
                </label>
                <input
                  type="text"
                  value={withdrawUpi}
                  onChange={(e) => setWithdrawUpi(e.target.value)}
                  placeholder="e.g. mobile@upi or username@okhdfcbank"
                  disabled={Boolean(activeRoom)}
                  className="w-full bg-[#0d121c] border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Or Bank NEFT */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1 uppercase tracking-wider">
                    Bank Name
                  </label>
                  <input
                    type="text"
                    value={withdrawBank}
                    onChange={(e) => setWithdrawBank(e.target.value)}
                    placeholder="e.g. HDFC Bank"
                    disabled={Boolean(activeRoom)}
                    className="w-full bg-[#0d121c] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1 uppercase tracking-wider">
                    Account Holder
                  </label>
                  <input
                    type="text"
                    value={withdrawHolder}
                    onChange={(e) => setWithdrawHolder(e.target.value)}
                    placeholder="e.g. Vikram Sharma"
                    disabled={Boolean(activeRoom)}
                    className="w-full bg-[#0d121c] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              {/* Submit Withdrawal */}
              <button
                onClick={handleWithdrawal}
                disabled={withdrawLoading || Boolean(activeRoom) || (user?.coins || 0) < withdrawCoins}
                className={`w-full py-3.5 rounded-xl font-black text-xs uppercase tracking-wider shadow-lg transition-all ${
                  withdrawLoading || Boolean(activeRoom) || (user?.coins || 0) < withdrawCoins
                    ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                    : 'bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-400 text-black shadow-[0_0_20px_rgba(245,158,11,0.3)]'
                }`}
              >
                {withdrawLoading
                  ? 'Submitting...'
                  : `Debit ${withdrawCoins} Coins & Request ₹${netPayout.toFixed(2)} Payout`}
              </button>

              <p className="text-[10px] text-center text-slate-400 leading-tight">
                ⚡ Processed via manual bank settlement within 24 operational hours. 100% coins auto-refunded if bank details are rejected.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Edge Case 6: Amount Mismatch Single-Attempt Correction Modal */}
      {mismatchModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-[#0d121c] border-2 border-yellow-500/50 rounded-2xl p-6 text-center shadow-2xl animate-in zoom-in-95">
            <div className="w-12 h-12 rounded-full bg-yellow-500/10 text-yellow-400 mx-auto flex items-center justify-center mb-3">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white mb-1 font-['Cinzel']">
              Amount Mismatch Detected!
            </h3>
            <p className="text-xs text-slate-300 mb-4 leading-relaxed">
              The transferred bank amount does not match your requested {reservation?.amount} Coins.
              <br />
              <strong className="text-yellow-300">Single Attempt:</strong> Enter the exact Rupee amount you transferred via UPI to verify and credit coins immediately.
            </p>

            <input
              type="number"
              value={correctedAmountInput}
              onChange={(e) => setCorrectedAmountInput(e.target.value)}
              placeholder="Enter exact transferred INR"
              className="w-full bg-[#07090e] border border-yellow-500/50 rounded-xl px-4 py-2.5 text-center font-mono font-bold text-yellow-300 mb-4 focus:outline-none"
            />

            <div className="flex gap-2">
              <button
                onClick={() => setMismatchModalOpen(false)}
                className="flex-1 py-2 rounded-xl text-xs bg-slate-800 text-slate-300"
              >
                Cancel
              </button>
              <button
                onClick={handleAmountCorrection}
                disabled={loading || !correctedAmountInput}
                className="flex-1 py-2 rounded-xl text-xs font-bold bg-yellow-500 hover:bg-yellow-400 text-black shadow-md"
              >
                {loading ? 'Verifying...' : 'Verify Correct Amount'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
