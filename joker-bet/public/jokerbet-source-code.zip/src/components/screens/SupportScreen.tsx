import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { SupportTicket } from '../../types/index';
import {
  HelpCircle,
  Send,
  MessageSquare,
  Shield,
  CheckCircle2,
  AlertCircle,
  FileText,
  Clock,
  Sparkles,
} from 'lucide-react';

export const SupportScreen: React.FC = () => {
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [category, setCategory] = useState<'Deposit' | 'Withdrawal' | 'Game' | 'Other' | 'Self-Exclusion'>('Deposit');
  const [referenceId, setReferenceId] = useState('');
  const [description, setDescription] = useState('');
  const [screenshotUrl, setScreenshotUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const loadTickets = async () => {
    try {
      const res = await api.getMyTickets();
      if (res.success) {
        setTickets(res.tickets || []);
      }
    } catch (err) {
      console.error('Failed to load tickets:', err);
    }
  };

  useEffect(() => {
    loadTickets();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) {
      setMsg({ type: 'error', text: 'Please write a brief description of your issue' });
      return;
    }

    setMsg(null);
    setLoading(true);
    try {
      const res = await api.createTicket({
        category,
        referenceId: referenceId.trim() || undefined,
        description,
        screenshotUrl: screenshotUrl.trim() || undefined,
      });

      if (res.success) {
        setMsg({ type: 'success', text: res.message });
        setDescription('');
        setReferenceId('');
        setScreenshotUrl('');
        await loadTickets();
      }
    } catch (err: any) {
      setMsg({ type: 'error', text: err.message || 'Failed to submit ticket' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full flex-1 flex flex-col justify-between p-4 bg-[#07090e] text-slate-100 select-none pb-16">
      <div>
        <div className="mb-4">
          <h2 className="text-xl font-black text-white font-['Cinzel']">Customer Support Desk</h2>
          <p className="text-xs text-slate-400">24/7 Operations Desk for UTR verification, payouts & self-exclusion</p>
        </div>

        {/* Feedback message */}
        {msg && (
          <div
            className={`p-3 rounded-xl border flex items-center gap-2 text-xs mb-3 ${
              msg.type === 'success'
                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                : 'bg-red-500/10 border-red-500/30 text-red-300'
            }`}
          >
            {msg.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0" />
            )}
            <span>{msg.text}</span>
          </div>
        )}

        {/* Ticket Submission Form */}
        <form onSubmit={handleSubmit} className="p-4 rounded-2xl bg-[#0c101c] border border-slate-800 space-y-3 mb-5">
          <div className="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
            <MessageSquare className="w-3.5 h-3.5 text-amber-400" />
            <span>Open New Support Ticket</span>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1">Issue Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full bg-[#07090e] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
              >
                <option value="Deposit">Deposit / UTR Delay</option>
                <option value="Withdrawal">Withdrawal / Bank Transfer</option>
                <option value="Game">Game Outcome Query</option>
                <option value="Self-Exclusion">Self-Exclusion / Cool-off</option>
                <option value="Other">Other Query</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1">Reference ID (UTR/Room)</label>
              <input
                type="text"
                value={referenceId}
                onChange={(e) => setReferenceId(e.target.value)}
                placeholder="e.g. 408512349876"
                className="w-full bg-[#07090e] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-400 mb-1">Detailed Description</label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Please describe the issue, transaction timing, or dispute..."
              className="w-full bg-[#07090e] border border-slate-700 rounded-xl p-3 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-amber-500"
            />
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-400 mb-1">
              Payment Screenshot URL <span className="text-slate-500">(Optional)</span>
            </label>
            <input
              type="text"
              value={screenshotUrl}
              onChange={(e) => setScreenshotUrl(e.target.value)}
              placeholder="https://... or image link"
              className="w-full bg-[#07090e] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-amber-500"
            />
          </div>

          <button
            type="submit"
            disabled={loading || !description.trim()}
            className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-black font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5"
          >
            <Send className="w-3.5 h-3.5" />
            <span>{loading ? 'Submitting Ticket...' : 'Submit Support Ticket'}</span>
          </button>
        </form>

        {/* Existing Tickets List */}
        <div>
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5 text-amber-400" />
            Your Support Threads ({tickets.length})
          </h3>

          {tickets.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-600 bg-[#090d16] rounded-2xl border border-slate-800">
              No support tickets submitted yet.
            </div>
          ) : (
            <div className="space-y-3">
              {tickets.map((t) => (
                <div key={t.id} className="p-3 rounded-2xl bg-[#0b0e17] border border-slate-800 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-amber-300">
                      [{t.category}] {t.referenceId ? `#${t.referenceId}` : ''}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        t.status === 'RESOLVED'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                          : 'bg-yellow-500/10 text-yellow-300 border border-yellow-500/30'
                      }`}
                    >
                      {t.status}
                    </span>
                  </div>

                  <p className="text-slate-300 leading-relaxed bg-[#07090e] p-2.5 rounded-xl border border-slate-800/80">
                    {t.description}
                  </p>

                  {/* Replies thread */}
                  {t.replies && t.replies.length > 1 && (
                    <div className="space-y-1.5 pt-1 border-t border-slate-800">
                      <div className="text-[10px] uppercase font-bold text-slate-400">Operations Desk Reply:</div>
                      {t.replies.slice(1).map((r, ri) => (
                        <div
                          key={ri}
                          className="p-2 rounded-xl bg-amber-500/5 border border-amber-500/20 text-slate-200 text-xs"
                        >
                          <span className="font-bold text-amber-400 mr-1.5">[Admin Desk]:</span>
                          <span>{r.message}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
