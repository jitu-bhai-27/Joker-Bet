import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import {
  Coins,
  Plus,
  Users,
  Flame,
  Wallet,
  Clock,
  HelpCircle,
  Trophy,
  ChevronRight,
  Shield,
  Volume2,
} from 'lucide-react';

export const LobbyScreen: React.FC = () => {
  const { user, config, joinRoomTier, setCurrentScreen, setWalletTab } = useApp();
  const [tiers, setTiers] = useState<any[]>([]);
  const [loadingTierId, setLoadingTierId] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  // Fetch live room tier states
  useEffect(() => {
    const loadRooms = async () => {
      try {
        const res = await api.getRooms();
        if (res.success && res.tiers) {
          setTiers(res.tiers);
        }
      } catch (err) {
        console.error('Failed to load room tiers:', err);
      }
    };

    loadRooms();
    const interval = setInterval(loadRooms, 3000);
    return () => clearInterval(interval);
  }, []);

  const handleJoin = async (tierId: string, entryCoins: number) => {
    if (!user) {
      setCurrentScreen('AUTH');
      return;
    }

    if (user.coins < entryCoins) {
      setErrorMsg(`Insufficient coins! You need ${entryCoins} Coins to enter, but have ${user.coins}.`);
      setWalletTab('DEPOSIT');
      setTimeout(() => setCurrentScreen('WALLET'), 1200);
      return;
    }

    setErrorMsg('');
    setLoadingTierId(tierId);
    const res = await joinRoomTier(tierId);
    setLoadingTierId(null);
    if (!res.success && res.message) {
      setErrorMsg(res.message);
    }
  };

  const activeTiers = tiers.length > 0 ? tiers : config?.roomTiers || [];

  return (
    <div className="w-full flex-1 flex flex-col justify-between bg-[#07090e] text-slate-100 select-none pb-16">
      {/* Top Header Bar */}
      <header className="px-4 py-3 bg-[#0a0e17] border-b border-amber-500/20 flex items-center justify-between shadow-md">
        {/* User Identity */}
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 p-[2px] shadow-sm">
            <div className="w-full h-full rounded-full bg-[#0d121c] flex items-center justify-center text-xs font-black text-amber-300">
              {user?.username ? user.username.substring(1, 3).toUpperCase() : 'JB'}
            </div>
          </div>
          <div>
            <div className="text-xs font-bold text-white flex items-center gap-1">
              <span>{user?.username || '@guest_player'}</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            </div>
            <div className="text-[10px] text-amber-400/90 font-mono">1 Coin = ₹1.00 INR</div>
          </div>
        </div>

        {/* Balance Pill with "+" Deposit Shortcut */}
        <div className="flex items-center gap-1.5 bg-[#0f1523] border border-amber-500/40 rounded-full pl-3 pr-1 py-1 shadow-[0_0_15px_rgba(245,158,11,0.15)]">
          <Coins className="w-4 h-4 text-amber-400" />
          <span className="font-extrabold text-sm text-amber-200 font-mono tracking-tight mr-1">
            {user?.coins?.toLocaleString() || 0}
          </span>
          <button
            onClick={() => {
              setWalletTab('DEPOSIT');
              setCurrentScreen('WALLET');
            }}
            className="w-6 h-6 rounded-full bg-gradient-to-r from-amber-500 to-yellow-500 text-black flex items-center justify-center font-bold text-xs shadow-md hover:scale-105 active:scale-95 transition-all"
            title="Deposit Coins"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
        </div>
      </header>

      {/* Scrolling Announcement Marquee */}
      <div className="bg-[#0b101c] border-b border-slate-800/80 px-3 py-1.5 flex items-center gap-2 overflow-hidden text-xs">
        <Volume2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
        <div className="whitespace-nowrap animate-marquee flex items-center gap-8 text-[11px] text-slate-300">
          <span className="text-amber-300 font-semibold">⚡ LIVE WINNER:</span>
          <span>@lucky_raj won 2,000 Coins in Royal High-Roller!</span>
          <span className="text-emerald-400 font-semibold">• FAST PAYOUTS:</span>
          <span>Zero-loss algorithm active • 1 Coin = 1 INR • Multi-QR UPI Instant Deposits</span>
          <span className="text-amber-300 font-semibold">• 100% REFUND:</span>
          <span>Exit waiting room anytime before start for instant 100% refund.</span>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="p-4 space-y-4 flex-1 overflow-y-auto">
        {/* Error Notice */}
        {errorMsg && (
          <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl flex items-center justify-between text-xs text-red-300 animate-in fade-in">
            <span>{errorMsg}</span>
            <button onClick={() => setErrorMsg('')} className="text-red-400 font-bold ml-2">
              ✕
            </button>
          </div>
        )}

        {/* Hero Banner */}
        <div className="relative rounded-2xl bg-gradient-to-r from-amber-950/40 via-[#121724] to-[#0c101a] border border-amber-500/30 p-4 overflow-hidden shadow-lg">
          <div className="relative z-10 flex items-center justify-between">
            <div>
              <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/40 text-[10px] text-amber-300 font-bold tracking-wide uppercase mb-1">
                <Flame className="w-3 h-3 text-amber-400" />
                Featured 3-Card Table
              </div>
              <h2 className="text-lg font-black text-white font-['Cinzel'] tracking-wide">
                Pick Card. Lock It. Win 2.0x!
              </h2>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Min 3 to 10 players • 120s Matchmaking • Suspense 10s Reveal
              </p>
            </div>
            <div className="text-4xl filter drop-shadow-[0_0_12px_rgba(245,158,11,0.5)]">
              🃏
            </div>
          </div>
        </div>

        {/* 8 Dynamic Room Tier Cards (Grid) */}
        <div>
          <div className="flex items-center justify-between mb-2.5">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Trophy className="w-3.5 h-3.5 text-amber-400" />
              Active Room Tiers (8 Tiers)
            </h3>
            <span className="text-[10px] text-slate-500 font-mono">3 - 10 Players per Table</span>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            {activeTiers.map((tier: any) => {
              const isHighRoller = tier.entryCoins >= 500;
              const isLoading = loadingTierId === tier.id;

              return (
                <div
                  key={tier.id}
                  className={`relative rounded-xl p-3 border transition-all flex flex-col justify-between ${
                    isHighRoller
                      ? 'bg-gradient-to-b from-[#16120b] to-[#0b0e17] border-amber-500/40 hover:border-amber-400/80 shadow-[0_0_15px_rgba(245,158,11,0.08)]'
                      : 'bg-[#0c101a] border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {/* Top Tier Badge & Multiplier */}
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-bold text-slate-200 truncate pr-1">
                      {tier.name}
                    </span>
                    <span className="text-[10px] font-black px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                      2.0x
                    </span>
                  </div>

                  {/* Entry & Prize */}
                  <div className="space-y-0.5 mb-3">
                    <div className="flex items-baseline gap-1">
                      <span className="text-lg font-black text-amber-300 font-mono">
                        {tier.entryCoins}
                      </span>
                      <span className="text-[10px] text-slate-400 uppercase">Coins</span>
                    </div>
                    <div className="text-[10px] text-emerald-400 font-semibold">
                      Win {(tier.entryCoins * (tier.winnerMultiplier || 2.0)).toLocaleString()} Coins
                    </div>
                  </div>

                  {/* Active Count & Join Button */}
                  <div className="flex items-center justify-between gap-1 pt-2 border-t border-slate-800/80">
                    <div className="flex items-center gap-1 text-[10px] text-slate-400">
                      <Users className="w-3 h-3 text-slate-500" />
                      <span>{tier.currentPlayers || 0} online</span>
                    </div>

                    <button
                      onClick={() => handleJoin(tier.id, tier.entryCoins)}
                      disabled={isLoading}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold tracking-wide transition-all ${
                        isHighRoller
                          ? 'bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-black shadow-md'
                          : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                      }`}
                    >
                      {isLoading ? 'Joining...' : 'Join Table'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Responsible Gaming & Security Footer Notice */}
        <div className="p-3 rounded-xl bg-[#090d16] border border-slate-800/80 flex items-center gap-2.5">
          <Shield className="w-5 h-5 text-emerald-400 shrink-0" />
          <div className="text-[10px] text-slate-400 leading-tight">
            <strong className="text-slate-300">Fully Encrypted Real-Time Engine:</strong> All entries are frozen securely. Disconnection grace periods and 100% exit refunds are automatically enforced by the server state machine.
          </div>
        </div>
      </div>

      {/* Bottom Sticky Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 max-w-[430px] mx-auto bg-[#080b13]/95 backdrop-blur-md border-t border-slate-800 px-4 py-2 flex items-center justify-around z-40">
        <button
          onClick={() => setCurrentScreen('LOBBY')}
          className="flex flex-col items-center gap-0.5 text-amber-400"
        >
          <Trophy className="w-4 h-4" />
          <span className="text-[10px] font-bold">Lobby</span>
        </button>

        <button
          onClick={() => setCurrentScreen('WALLET')}
          className="flex flex-col items-center gap-0.5 text-slate-400 hover:text-slate-200"
        >
          <Wallet className="w-4 h-4" />
          <span className="text-[10px] font-medium">Wallet</span>
        </button>

        <button
          onClick={() => setCurrentScreen('HISTORY')}
          className="flex flex-col items-center gap-0.5 text-slate-400 hover:text-slate-200"
        >
          <Clock className="w-4 h-4" />
          <span className="text-[10px] font-medium">History</span>
        </button>

        <button
          onClick={() => setCurrentScreen('SUPPORT')}
          className="flex flex-col items-center gap-0.5 text-slate-400 hover:text-slate-200"
        >
          <HelpCircle className="w-4 h-4" />
          <span className="text-[10px] font-medium">Support</span>
        </button>
      </nav>
    </div>
  );
};
