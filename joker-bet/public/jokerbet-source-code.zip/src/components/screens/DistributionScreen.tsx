import React from 'react';
import { useApp } from '../../context/AppContext';
import { PWAInstallButton } from '../common/PWAInstallButton';
import {
  DownloadCloud,
  Send,
  Smartphone,
  Share2,
  CheckCircle2,
  ArrowLeft,
  ShieldCheck,
  FileCode,
} from 'lucide-react';

export const DistributionScreen: React.FC = () => {
  const { config, setCurrentScreen } = useApp();

  return (
    <div className="w-full flex-1 flex flex-col justify-between p-4 bg-[#07090e] text-slate-100 select-none pb-12">
      <div>
        {/* Back Button */}
        <button
          onClick={() => setCurrentScreen('LOBBY')}
          className="flex items-center gap-1.5 text-xs text-amber-400 hover:text-amber-300 mb-4 font-bold"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Game Lobby</span>
        </button>

        {/* Header */}
        <div className="text-center mb-6">
          <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-sky-400 to-blue-600 mx-auto flex items-center justify-center text-3xl shadow-[0_0_30px_rgba(14,165,233,0.4)] mb-3">
            🃏
          </div>
          <h2 className="text-2xl font-black text-white font-['Cinzel'] tracking-wide">
            Official App Distribution
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Android APK v1.0.4 & iOS Web PWA • No Play Store Delays
          </p>
        </div>

        {/* Telegram Official Channel Release Post Card */}
        <div className="p-4 rounded-2xl bg-[#0c121e] border border-sky-500/30 space-y-3 mb-4 shadow-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-[#229ED9] flex items-center justify-center text-white">
                <Send className="w-3.5 h-3.5" />
              </div>
              <span className="font-bold text-sm text-sky-300">Telegram Release Channel</span>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30">
              VERIFIED CLEAN
            </span>
          </div>

          <div className="p-3 rounded-xl bg-[#070a12] border border-slate-800 text-xs text-slate-300 font-mono leading-relaxed space-y-1">
            <div className="text-amber-300 font-bold">🃏 JOKER BET - OFFICIAL ANDROID RELEASE (v1.0.4) 🃏</div>
            <div>⚡ Play Real-Money 3-Card Joker | 1 Coin = ₹1 INR</div>
            <div>⚡ Instant Multi-QR UPI Deposits | 24-Hour Verified Withdrawals</div>
            <div className="pt-1 text-slate-400">
              📦 File: <span className="text-sky-300">JokerBet_v1.0.4.apk</span> | Size: ~18 MB | SHA-256 Validated
            </div>
            <div className="text-slate-400">⚠️ Minimum: Android 7.0 (Nougat) and above.</div>
          </div>

          {/* Action Buttons & Direct Download Triggers */}
          <div className="space-y-2.5 pt-1">
            {/* Native Android / iOS One-Tap PWA/WebAPK Installer */}
            <PWAInstallButton />

            <a
              href={config?.telegramChannelUrl || 'https://t.me/JokerBetOfficial'}
              target="_blank"
              rel="noreferrer"
              className="flex items-center justify-center gap-2 w-full py-3 bg-[#229ED9] hover:bg-[#1e8ec4] text-white font-extrabold text-xs rounded-xl shadow-lg transition-all"
            >
              <Send className="w-4 h-4" />
              <span>Join Official Telegram Channel</span>
            </a>

            {/* Direct Instant Download Button (Blob + Iframe Safe) */}
            <button
              onClick={() => {
                try {
                  // Direct fetch with blob download fallback that works in all browsers and iframes
                  fetch('/api/download/apk')
                    .then((res) => res.blob())
                    .then((blob) => {
                      const url = window.URL.createObjectURL(new Blob([blob], { type: 'application/vnd.android.package-archive' }));
                      const a = document.createElement('a');
                      a.style.display = 'none';
                      a.href = url;
                      a.download = 'JokerBet_v1.0.4.apk';
                      document.body.appendChild(a);
                      a.click();
                      window.URL.revokeObjectURL(url);
                      document.body.removeChild(a);
                    })
                    .catch(() => {
                      // Fallback: direct window navigation
                      window.location.href = '/api/download/apk';
                    });
                } catch (e) {
                  window.location.href = '/api/download/apk';
                }
              }}
              className="flex items-center justify-center gap-2 w-full py-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-black font-extrabold text-xs rounded-xl shadow-[0_0_20px_rgba(16,185,129,0.3)] transition-all transform active:scale-95"
            >
              <DownloadCloud className="w-4 h-4 text-black" />
              <span>Download Direct APK Mirror (Click to Download)</span>
            </button>

            {/* Copy Direct URL Box for Mobile Browser */}
            <div className="p-2.5 rounded-xl bg-[#070a12] border border-slate-800 space-y-1.5">
              <div className="text-[10px] text-slate-400 font-semibold flex items-center justify-between">
                <span>Direct Link (Paste in Chrome / Safari on Phone):</span>
                <span className="text-emerald-400 font-mono">HTTPS READY</span>
              </div>
              <div className="flex items-center justify-between gap-2 bg-[#0d121c] p-2 rounded-lg border border-slate-700">
                <span className="font-mono text-[10px] text-slate-300 truncate select-all">
                  {window.location.origin}/api/download/apk
                </span>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(`${window.location.origin}/api/download/apk`);
                    alert('Direct download link copied to clipboard!');
                  }}
                  className="px-2 py-1 rounded bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-[10px] font-bold shrink-0 border border-amber-500/30"
                >
                  Copy Link
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Installation Guides for Android & iOS */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {/* Android Guide */}
          <div className="p-3.5 rounded-xl bg-[#0b0e17] border border-slate-800 space-y-2 text-xs">
            <div className="flex items-center gap-2 text-emerald-400 font-bold">
              <Smartphone className="w-4 h-4" />
              <span>Android Installation Guide</span>
            </div>
            <ol className="list-decimal list-inside text-slate-400 space-y-1 text-[11px] leading-relaxed">
              <li>Download the APK file directly or via Telegram.</li>
              <li>Tap the file and select <strong className="text-slate-200">Install</strong>.</li>
              <li>If prompted, enable <em className="text-slate-300">&apos;Allow from this source&apos;</em>.</li>
              <li>Launch Joker Bet and enter your Email OTP.</li>
            </ol>
          </div>

          {/* iOS Guide */}
          <div className="p-3.5 rounded-xl bg-[#0b0e17] border border-slate-800 space-y-2 text-xs">
            <div className="flex items-center gap-2 text-sky-400 font-bold">
              <Share2 className="w-4 h-4" />
              <span>iOS (iPhone / iPad) Instant PWA</span>
            </div>
            <ol className="list-decimal list-inside text-slate-400 space-y-1 text-[11px] leading-relaxed">
              <li>Open this app URL in <strong className="text-slate-200">Safari</strong>.</li>
              <li>Tap the <strong className="text-slate-200">Share</strong> icon at the bottom of Safari.</li>
              <li>Select <strong className="text-slate-200">&apos;Add to Home Screen&apos;</strong>.</li>
              <li>Tap Add. Launch directly from your home screen as a standalone app!</li>
            </ol>
          </div>
        </div>
      </div>

      {/* Security Disclaimer */}
      <div className="p-3 rounded-xl bg-[#090d16] border border-slate-800/80 flex items-center gap-2 mt-4 text-[10px] text-slate-500">
        <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
        <span>
          Direct Distribution ensures instant updates, zero middleman store cuts, and optimal payout limits for players.
        </span>
      </div>
    </div>
  );
};
