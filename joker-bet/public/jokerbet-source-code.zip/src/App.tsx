import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { DeviceFrame } from './components/common/DeviceFrame';
import { SplashScreen } from './components/screens/SplashScreen';
import { AuthScreen } from './components/screens/AuthScreen';
import { LobbyScreen } from './components/screens/LobbyScreen';
import { WaitingRoomScreen } from './components/screens/WaitingRoomScreen';
import { GameTableScreen } from './components/screens/GameTableScreen';
import { WalletScreen } from './components/screens/WalletScreen';
import { HistoryScreen } from './components/screens/HistoryScreen';
import { SupportScreen } from './components/screens/SupportScreen';
import { DistributionScreen } from './components/screens/DistributionScreen';
import { AdminPanel } from './components/admin/AdminPanel';

const ScreenRouter: React.FC = () => {
  const { currentScreen } = useApp();

  switch (currentScreen) {
    case 'SPLASH':
      return <SplashScreen />;
    case 'AUTH':
      return <AuthScreen />;
    case 'LOBBY':
      return <LobbyScreen />;
    case 'WAITING':
      return <WaitingRoomScreen />;
    case 'GAME':
      return <GameTableScreen />;
    case 'WALLET':
      return <WalletScreen />;
    case 'HISTORY':
      return <HistoryScreen />;
    case 'SUPPORT':
      return <SupportScreen />;
    case 'DISTRIBUTION':
      return <DistributionScreen />;
    case 'ADMIN':
      return <AdminPanel />;
    default:
      return <LobbyScreen />;
  }
};

export default function App() {
  return (
    <AppProvider>
      <DeviceFrame>
        <ScreenRouter />
      </DeviceFrame>
    </AppProvider>
  );
}
